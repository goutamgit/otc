export class GlobalConstants {
	public static apiURL: string = "http://localhost:8091/api";
	//public static apiURL: string = "http://10.114.44.205:8091/api";
	public static currentSprint: string = "Sprint-12";
}
