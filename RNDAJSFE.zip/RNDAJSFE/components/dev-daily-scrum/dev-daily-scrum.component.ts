import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dev-daily-scrum',
  templateUrl: './dev-daily-scrum.component.html',
  styleUrls: ['./dev-daily-scrum.component.css']
})
export class DevDailyScrumComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
