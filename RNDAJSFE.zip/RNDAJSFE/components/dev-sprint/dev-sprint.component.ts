import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dev-sprint',
  templateUrl: './dev-sprint.component.html',
  styleUrls: ['./dev-sprint.component.css']
})
export class DevSprintComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
