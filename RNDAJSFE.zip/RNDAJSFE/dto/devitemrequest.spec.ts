import { Devitemrequest } from './devitemrequest';

describe('Devitemrequest', () => {
  it('should create an instance', () => {
    expect(new Devitemrequest()).toBeTruthy();
  });
});
