export class Devitemrequest {
	itemNumber:String;
	itemSprintName:String = 'All';
	itemStatus:String = 'All';
	applicationName:String = 'All';
	developerName:String = 'All';
    projectName:String = 'All';
    itemPriority:String = 'All';
    isRefined:String;
    itemType:String = 'All';
    task:boolean = false;
    subTask:boolean = false;
}
