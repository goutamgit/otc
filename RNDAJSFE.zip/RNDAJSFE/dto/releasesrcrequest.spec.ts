import { Releasesrcrequest } from './releasesrcrequest';

describe('Releasesrcrequest', () => {
  it('should create an instance', () => {
    expect(new Releasesrcrequest()).toBeTruthy();
  });
});
