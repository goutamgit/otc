export class Releasesrcrequest {
	applicationName:String = 'All';
	uatStartDate:Date;
	uatSignoffDate:Date;
	uatRfcNumber:number;
	postUatBugCount:number;
	prdReleaseDate:Date;
	prdRfcNumber:number;
	postPrdBugCount:number;
}
