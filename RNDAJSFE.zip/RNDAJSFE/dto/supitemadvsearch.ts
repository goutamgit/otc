export class SupitemAdvSearch {
    itemNumber:number = 0 ;
    itemFromDate:Date;
    itemToDate:Date;
    opneDate:boolean;
    closeDate:boolean;
    applicationName:String = 'All';
    bounce:boolean;
    itemStatus:String = 'All';
    itemType:String = 'All';
    itemAssigned:String = 'All';
    sla:String = 'All';
    debt:String = 'All';
    priority:number;
    searchText:String;
}