import { TaskSchedulerRequest } from './task-scheduler-request';

describe('TaskSchedulerRequest', () => {
  it('should create an instance', () => {
    expect(new TaskSchedulerRequest()).toBeTruthy();
  });
});
