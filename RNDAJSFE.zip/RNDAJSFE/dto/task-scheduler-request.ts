export class TaskSchedulerRequest {
taskStatus:String='All';
priority:String='All';
followUpTo:String;
taskScheduledStartDate:Date;
taskScheduledEndDate:Date;
}
