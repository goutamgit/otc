import { AppConfigProperties } from './app-config-properties';

describe('AppConfigProperties', () => {
  it('should create an instance', () => {
    expect(new AppConfigProperties()).toBeTruthy();
  });
});
