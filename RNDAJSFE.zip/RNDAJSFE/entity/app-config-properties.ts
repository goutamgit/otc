export class AppConfigProperties {
	configurationPropertiesId:number;
	configName:String;
	configValue:String;
}
