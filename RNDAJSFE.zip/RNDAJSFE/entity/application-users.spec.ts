import { ApplicationUsers } from './application-users';

describe('ApplicationUsers', () => {
  it('should create an instance', () => {
    expect(new ApplicationUsers()).toBeTruthy();
  });
});
