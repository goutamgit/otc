export class ApplicationUsers {
	applicationUserId:number;
	userRole:String;
    userId:String;
    userFullName:String;
    password:String;
}
