import { Dailyscrumactivity } from './dailyscrumactivity';

describe('Dailyscrumactivity', () => {
  it('should create an instance', () => {
    expect(new Dailyscrumactivity()).toBeTruthy();
  });
});
