export class Dailyscrumactivity {
}
