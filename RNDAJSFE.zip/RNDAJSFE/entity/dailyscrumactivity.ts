export class Dailyscrumactivity {
dailyScrumId:number;
sprintName:String;
devItem:String;
currentStatus:String;
resourceName:String;
statusDate:Date;
}
