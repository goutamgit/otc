import { Devitem } from './devitem';

describe('Devitem', () => {
  it('should create an instance', () => {
    expect(new Devitem()).toBeTruthy();
  });
});
