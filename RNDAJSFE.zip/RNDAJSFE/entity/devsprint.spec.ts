import { Devsprint } from './devsprint';

describe('Devsprint', () => {
  it('should create an instance', () => {
    expect(new Devsprint()).toBeTruthy();
  });
});
