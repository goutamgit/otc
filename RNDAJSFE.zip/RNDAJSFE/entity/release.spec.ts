import { Release } from './release';

describe('Release', () => {
  it('should create an instance', () => {
    expect(new Release()).toBeTruthy();
  });
});
