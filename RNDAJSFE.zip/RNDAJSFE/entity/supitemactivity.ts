export class Supitemactivity {
	supportItemActivityId:number;
	itemId:number;
    itemActivity:String;
    itemActivityDate:Date;
}