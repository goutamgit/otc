export class TaskSchedulerActivity {
taskSchedulerActivityId:number;
taskSchedulerId:number;
taskActivity:String;
activityCreatedDate:Date;
}
