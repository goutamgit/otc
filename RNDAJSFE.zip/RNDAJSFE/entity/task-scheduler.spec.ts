import { TaskScheduler } from './task-scheduler';

describe('TaskScheduler', () => {
  it('should create an instance', () => {
    expect(new TaskScheduler()).toBeTruthy();
  });
});
