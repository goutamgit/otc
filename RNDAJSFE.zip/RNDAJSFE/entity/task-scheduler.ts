export class TaskScheduler {
taskSchedulerId:number;
taskName:String;
priority:String;
taskDescription:String;
followUpTo:String;
taskStatus:String;
comment:String;
taskScheduledDate:Date;
}
