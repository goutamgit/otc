import { Component, OnInit } from '@angular/core';
import { FormControl,FormGroup,Validators} from '@angular/forms';
import { ReleaseService } from '../../service/release.service';
import { Release } from '../../entity/release';
import { Releasesrcrequest } from '../../dto/releasesrcrequest';
import { NgxSpinnerService } from "ngx-spinner";
import { Observable,Subject } from "rxjs";
import{ GlobalConstants } from '../../common/global-constants';

@Component({
  selector: 'app-release-item',
  templateUrl: './release-item.component.html',
  styleUrls: ['./release-item.component.css']
})
export class ReleaseItemComponent implements OnInit {

  constructor(private releaseService: ReleaseService,private spinner: NgxSpinnerService) {
  	this.config = {
      currentPage: 1,
      itemsPerPage: 50,
      totalItems:3
    };
   }

config: any; 
releasesrcrequestAttributes : Releasesrcrequest=new Releasesrcrequest();
releaseObj : Release = new Release();
releaseObjList: Observable<Release[]>;
advanceSearchToggleBtnclickEventstats: boolean = false;
submitted = false;
public date: any;
allApplicatoinNameList : any=[];

  ngOnInit() {
  	this.getPage(1);
    this.loadPageConfiguration();
  }

   getPage(page: number) {
      this.spinner.show();
      this.config.currentPage=page;
      console.log(this.releasesrcrequestAttributes);
      this.releaseService.getAllReleaseItemByRequest(this.releasesrcrequestAttributes,page).subscribe(data =>{

        this.releaseObjList = this.getReleaseItemDataContent(data,'content');
        this.config.totalItems = this.getReleaseItemDataContent(data,'totalElements');
        this.spinner.hide();
      });  
    }

  releaseitemsaveform=new FormGroup({
    release_from_id:new FormControl(),
    application_name:new FormControl(''),
    rfc_number:new FormControl(),
    deployment_date:new FormControl(),
    singoff_date:new FormControl(),
    environment_name:new FormControl('All'),
    bug_count:new FormControl(),
    item_subject:new FormControl(),
    item_description:new FormControl(),
    comment:new FormControl(),
    release_status:new FormControl(),
  });  

    releasesrcform = new FormGroup({
      src_application_name:new FormControl('All')
    });

      getUpdateReleaseItem(taskSchedulerId){
      this.releaseObj=new Release();
      this.releaseService.getReleaseItemById(taskSchedulerId).subscribe(data =>{
         this.releaseitemsaveform.patchValue({
         release_from_id:this.UpdatableTask(data,'releaseId'),
         application_name:this.UpdatableTask(data,'applicationName'),
         rfc_number:this.UpdatableTask(data,'rfcNumber'),
         deployment_date:this.UpdatableTask(data,'deploymentDate'),
         singoff_date:this.UpdatableTask(data,'signoffDate'),
         environment_name:this.UpdatableTask(data,'environmentName'),
         bug_count:this.UpdatableTask(data,'bugCount'),
         item_subject:this.UpdatableTask(data,'itemSubject'),
         comment:this.UpdatableTask(data,'comment'),
         release_status:this.UpdatableTask(data,'releaseStatus'),
         item_description:this.UpdatableTask(data,'itemDescription')});
    });
  }

    UpdatableTask(updateItemObject:Object,updateItemName:any){
    return updateItemObject[updateItemName];
  }

  addItemModalClose(){
    this.releaseitemsaveform.reset();
  }

    saveAndUpdateReleaseItem(saveItem){
    this.releaseObj = new Release();
    this.releaseObj.itemSubject=this.ItemSubject.value;
    this.releaseObj.itemDescription=this.ItemDescription.value;
    this.releaseObj.applicationName=this.ApplicationName.value;
    this.releaseObj.rfcNumber=this.RfcNumber.value;
    this.releaseObj.environmentName=this.EnvironmentName.value;
    this.releaseObj.deploymentDate=this.DeploymentDate.value;
    this.releaseObj.signoffDate=this.SignOffDate.value;
    this.releaseObj.bugCount=this.BugCount.value;
    this.releaseObj.comment=this.Comment.value;
    this.releaseObj.releaseStatus=this.ReleaseStatus.value;
    

    if(this.ReleaseFormID.value==null || this.ReleaseFormID.value==''){
         this.saveReleaseItem();
    }else{
        this.releaseObj.releaseId=this.ReleaseFormID.value;
        this.updateReleaseItem();
    }
    
    this.submitted = true;    
    this.releaseitemsaveform.reset();
  }



   saveReleaseItem() {
    this.releaseService.createReleaseItem(this.releaseObj)
      .subscribe(data => {
        this.getPage(this.config.currentPage);
        this.modalCloseJquery();
      });
    this.releaseObj = new Release();
  }

    updateReleaseItem() {
    this.releaseService.updateReleaseItem(this.releaseObj.releaseId,this.releaseObj)
      .subscribe(data => {
        this.getPage(this.config.currentPage);
        this.modalCloseJquery();
      });
    this.releaseObj = new Release();
  }

  getReleaseItemDataContent(responseData:Object,contentName:any){
  console.log(responseData[contentName]);
    return responseData[contentName];
  }

  advanceSearchToggleBtnclickEvent(){
    this.advanceSearchToggleBtnclickEventstats = !this.advanceSearchToggleBtnclickEventstats; 
  }

  getRemoveReleaseItem(releaseItemId){
  if(confirm("Are you sure to delete this Task "+releaseItemId)) {
          //console.log("Implement delete functionality here");
          this.releaseService.deleteReleaseItem(releaseItemId)
              .subscribe(data => {
              this.getPage(this.config.currentPage);
          });
          }
  }

   modalCloseJquery(){
    setTimeout(function() { 
          this.$('#releasemodal').modal('hide'); 
          this.$("#itemSubmitButton").prop('disabled', false);
          this.$("#itemSubmitButton").prop('class', 'btn btn-info');
          this.$("#itemSubmitButton").text("Save changes");
        }, 1000);
  }


  get ReleaseFormID(){
    return this.releaseitemsaveform.get('release_from_id');
  }
  get ItemSubject(){
    return this.releaseitemsaveform.get('item_subject');
  }
  get ItemDescription(){
    return this.releaseitemsaveform.get('item_description');
  }
  get ApplicationName(){
    return this.releaseitemsaveform.get('application_name');
  }
  get RfcNumber(){
    return this.releaseitemsaveform.get('rfc_number');
  }
  get DeploymentDate(){
    return this.releaseitemsaveform.get('deployment_date');
  }
  get SignOffDate(){
    return this.releaseitemsaveform.get('singoff_date');
  }
  
  get EnvironmentName(){
    return this.releaseitemsaveform.get('environment_name');
  }
  get BugCount(){
    return this.releaseitemsaveform.get('bug_count');
  }
  
  get Comment(){
    return this.releaseitemsaveform.get('comment');
  }
  get ReleaseStatus(){
    return this.releaseitemsaveform.get('release_status');
  }

  

  get ApplicationNameSRC(){
    return this.releasesrcform.get('src_application_name');
  }

loadPageConfiguration(){
      this.allApplicatoinNameList=GlobalConstants.getAllApplicationNames();
    }

getColorClass(role: string) {
  let returnValue;
  switch (role) {
  case 'Done':
    returnValue = 'done';
    break;
  case 'Inprogress':
    returnValue = 'inprogress';
    break;
}

return returnValue ;
}

}
