import { DevSprintsRequestAttributes } from './dev-sprints-request-attributes';

describe('DevSprintsRequestAttributes', () => {
  it('should create an instance', () => {
    expect(new DevSprintsRequestAttributes()).toBeTruthy();
  });
});
