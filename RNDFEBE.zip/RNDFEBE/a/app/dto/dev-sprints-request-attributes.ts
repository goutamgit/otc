export class DevSprintsRequestAttributes {
sprintName:String='All';
itemFromDate:Date;
itemToDate:Date;
isSpillOver:String='All';
opneDate:boolean=false;
closeDate:boolean=false;
}
