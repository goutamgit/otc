export class Devsprint {
	sprintId:number;
    sprintName:String;
    sprintOpenDate:Date;
    sprintCloseDate:Date;
    committedStoryPoint:number;
    deliverdStoryPoint:number;
    scopeCreep:number;
    scopeCreepDescription:String;
    spillOverSp:number;
    spillOverItem:String;
    isSpillOver:String;
    sprintCreatedDate:Date;
}
