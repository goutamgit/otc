import { TaskSchedulerActivity } from './task-scheduler-activity';

describe('TaskSchedulerActivity', () => {
  it('should create an instance', () => {
    expect(new TaskSchedulerActivity()).toBeTruthy();
  });
});
