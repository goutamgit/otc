package com.ca.reportsapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author Anupam Biswas
 * 2019-12-25 19:30:03.793
 */

@SpringBootApplication
public class CaReportsApplication {

	public static void main(String[] args) {
		SpringApplication.run(CaReportsApplication.class, args);
	}

}
