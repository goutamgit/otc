package com.ca.reportsapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CaReportsApplicationTests {

	@Test
	void contextLoads() {
	}

}
