export class ReportQueryMaster {
reportQueryId:number;
reportQuery:String;
mailTo:String;
mailCc:String;
mailSubject:String;
mailBody:String;
reportFilename:String;
reportSheetName:String;
reportName:String;
reportDescription:String;
activeInactive:String;
}
