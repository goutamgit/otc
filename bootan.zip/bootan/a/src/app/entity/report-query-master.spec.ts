import { ReportQueryMaster } from './report-query-master';

describe('ReportQueryMaster', () => {
  it('should create an instance', () => {
    expect(new ReportQueryMaster()).toBeTruthy();
  });
});
