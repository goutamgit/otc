export class DbaSchedulerJobRunDetailDTO {
	logDate:String;
    jobName:String;
    jobSubname:String;
    status:String;
    runDuration:String;
}
