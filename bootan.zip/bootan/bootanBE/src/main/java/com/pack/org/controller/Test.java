/**
 * 
 */
package com.pack.org.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


/**
 * @author Anupam Biswas
 * 2020-10-07 01:34:29.339
 */
@RestController
//@CrossOrigin(origins="${rest.client.origin}")
@RequestMapping(value="/api")
public class Test {
	
	@GetMapping("/getalljobs")
	public Map<String, String> retrieveAllItems() {
		HashMap<String, String> map = new HashMap<>();
	    map.put("key", "value");
	    map.put("foo", "bar");
	    map.put("aa", "bb");
	    return map;
	}

}
