/**
 * 
 */
package com.pack.org.dao.repository;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.pack.org.domain.entity.DbaSchedulerJobRunDetail;

/**
 * @author Anupam Biswas
 * 2020-10-10 18:39:33.522
 */
@Repository
public interface DbaSchedulerJobRunDetailRepository extends PagingAndSortingRepository<DbaSchedulerJobRunDetail, Long>{

}
