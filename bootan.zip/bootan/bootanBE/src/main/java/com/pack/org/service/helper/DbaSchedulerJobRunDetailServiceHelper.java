/**
 * 
 */
package com.pack.org.service.helper;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

import com.pack.org.domain.entity.DbaSchedulerJobRunDetail;
import com.pack.org.dto.DbaSchedulerJobRunDetailDTO;

/**
 * @author Anupam Biswas
 * 2020-10-10 19:37:43.394
 */
@Component
public class DbaSchedulerJobRunDetailServiceHelper {
	
	@Autowired
	EntityManager em;
	
	public Page<DbaSchedulerJobRunDetail> retrieveAdvSrcSupportItemPage(DbaSchedulerJobRunDetailDTO filter, Pageable pageable) {

        CriteriaBuilder builder =  em.getCriteriaBuilder();
        CriteriaQuery<DbaSchedulerJobRunDetail> criteria = builder.createQuery(DbaSchedulerJobRunDetail.class);
        Root<DbaSchedulerJobRunDetail> supportItemRoot = criteria.from(DbaSchedulerJobRunDetail.class);
        List<Predicate> predicates = new ArrayList<Predicate>();

		/*
		 * predicates.add(builder.equal(booksRoot.get("id"), params.getRequestId()));
		 * 
		 * predicates.add(builder.like(builder.lower(booksRoot.get("name")), "%" +
		 * params.getName().toLowerCase() + "%"));
		 */
        /*
        if(filter.getSearchText()!=null && !filter.getSearchText().equals("")) {
        	predicates.add(builder.or(builder.like(supportItemRoot.get("itemSubject"), "%"+filter.getSearchText()+"%"),builder.like(supportItemRoot.get("itemDescription"), "%"+filter.getSearchText()+"%"),builder.like(supportItemRoot.get("resoluation"), "%"+filter.getSearchText()+"%")));
        }
        */
        /*
         * Mysql so jali it dosent suppot inclusive between
        if(filter.isOpneDate() && filter.isCloseDate()) {		
        	predicates.add(builder.or(builder.between(supportItemRoot.get("itemCreatedDate"), filter.getItemFromDate(), filter.getItemToDate()), 
        					builder.between(supportItemRoot.get("itemCloseDate"), filter.getItemFromDate(), filter.getItemToDate())));		
        }
        
        if(filter.isOpneDate() && !filter.isCloseDate()) {
        	predicates.add(builder.between(supportItemRoot.get("itemCreatedDate"), filter.getItemFromDate(), filter.getItemToDate()));
        }
        
        if(!filter.isOpneDate() && filter.isCloseDate()) {
        	predicates.add(builder.between(supportItemRoot.get("itemCloseDate"), filter.getItemFromDate(), filter.getItemToDate()));
        }
        */
        /*
        if(filter.isOpneDate() && filter.isCloseDate()) {		
        	predicates.add(builder.or(builder.and(builder.greaterThanOrEqualTo(supportItemRoot.get("itemCreatedDate"), filter.getItemFromDate()), builder.lessThanOrEqualTo(supportItemRoot.get("itemCreatedDate"), filter.getItemToDate())), 
        			builder.and(builder.greaterThanOrEqualTo(supportItemRoot.get("itemCloseDate"), filter.getItemFromDate()), builder.lessThanOrEqualTo(supportItemRoot.get("itemCloseDate"), filter.getItemToDate()))));
        }
        
        
        if(filter.isOpneDate() && !filter.isCloseDate()) {
        	predicates.add(builder.and(builder.greaterThanOrEqualTo(supportItemRoot.get("itemCreatedDate"), filter.getItemFromDate()), builder.lessThanOrEqualTo(supportItemRoot.get("itemCreatedDate"), filter.getItemToDate())));
        }
        
        if(!filter.isOpneDate() && filter.isCloseDate()) {
        	predicates.add(builder.and(builder.greaterThanOrEqualTo(supportItemRoot.get("itemCloseDate"), filter.getItemFromDate()), builder.lessThanOrEqualTo(supportItemRoot.get("itemCloseDate"), filter.getItemToDate())));
        }
        
        if (filter.getItemNumber() != 0) {
			  predicates.add(builder.equal(supportItemRoot.get("itemNumber"), filter.getItemNumber())); 
		}
        
        if (!filter.getApplicationName().equals("All")) {
			  predicates.add(builder.equal(supportItemRoot.get("applicationName"), filter.getApplicationName())); 
		}
        
        if (!filter.getItemStatus().equals("All")) {
			  predicates.add(builder.equal(supportItemRoot.get("itemStatus"), filter.getItemStatus())); 
		}
        
        if (filter.isBounce()) {
			  predicates.add(builder.greaterThan(supportItemRoot.get("itemStatus"), 0)); 
		}
        
        if (!filter.getItemType().equals("All")) {
			  predicates.add(builder.equal(supportItemRoot.get("itemType"), filter.getItemType())); 
		}
        
        if (!filter.getItemAssigned().equals("All")) {
			  predicates.add(builder.equal(supportItemRoot.get("itemAssigned"), filter.getItemAssigned())); 
		}
        
        if (!filter.getSla().equals("All")) {
        	switch(filter.getSla())	{
        	case "NonAged":
        		predicates.add(builder.equal(supportItemRoot.get("aged"), "N")); 
        		break;
        	case "Aged":
        		predicates.add(builder.equal(supportItemRoot.get("aged"), "Y")); 
        		break;
        	case "Primary":
        		predicates.add(builder.equal(supportItemRoot.get("primarySlaBreached"), "Y")); 
        		break;
        	case "Secondary":
        		predicates.add(builder.equal(supportItemRoot.get("secondarySlaBreached"), "Y")); 
        		break;
        	case "Tertiary":
        		predicates.add(builder.equal(supportItemRoot.get("tertirySlaBreached"), "Y")); 
        		break;
        	}
		}
        
*/
        criteria.where(builder.and(predicates.toArray( new Predicate[predicates.size()])));

        criteria.orderBy(builder.desc(supportItemRoot.get("logDate")));

        // This query fetches the SupItem as per the Page Limit
        List<DbaSchedulerJobRunDetail> result = em.createQuery(criteria).setFirstResult((int) pageable.getOffset()).setMaxResults(pageable.getPageSize()).getResultList();

        // Create Count Query
        CriteriaQuery<Long> countQuery = builder.createQuery(Long.class);
        Root<DbaSchedulerJobRunDetail> supportItemRootRootCount = countQuery.from(DbaSchedulerJobRunDetail.class);
        countQuery.select(builder.count(supportItemRootRootCount)).where(builder.and(predicates.toArray(new Predicate[predicates.size()])));

        // Fetches the count of all SupItem as per given criteria
        Long count = em.createQuery(countQuery).getSingleResult();

        Page<DbaSchedulerJobRunDetail> result1 = new PageImpl<>(result, pageable, count);
        return result1;
    }
}
