import { Component, OnInit } from '@angular/core';
import { FormControl,FormGroup,Validators} from '@angular/forms';
import { DatePipe } from '@angular/common';
import{ GlobalConstants } from '../../conf/global-constants';
import { AllJobInfoService } from '../../service/all-job-info.service';
import { DbaSchedulerJobRunDetailDTO } from '../../dto/dba-scheduler-job-run-detail-dto';

@Component({
  selector: 'app-all-job-info',
  templateUrl: './all-job-info.component.html',
  styleUrls: ['./all-job-info.component.css']
})
export class AllJobInfoComponent implements OnInit {

applicationList:any;
supitemadvsearchattribute : DbaSchedulerJobRunDetailDTO = new DbaSchedulerJobRunDetailDTO();

  constructor(private allJobInfoService: AllJobInfoService) { 

this.config = {
      currentPage: 1,
      itemsPerPage: 50,
      totalItems:3
    };
  }

config: any; 
items: any[];

  ngOnInit(): void {
  this.getPage(1);
  }

  getPage(page: number){
    this.supitemadvsearchattribute = new DbaSchedulerJobRunDetailDTO();
    this.supitemadvsearchattribute.logDate = null;
    this.supitemadvsearchattribute.jobName = '';
    this.supitemadvsearchattribute.jobSubname = '';
    this.supitemadvsearchattribute.status = '';
    this.supitemadvsearchattribute.runDuration = '';

    console.log(this.supitemadvsearchattribute);
    this.allJobInfoService.getAllJobDetail(this.supitemadvsearchattribute,page).subscribe(data =>{
        this.items = this.getSupItemDataContent(data,'content');
        console.log(data);
        this.config.totalItems = this.getSupItemDataContent(data,'totalElements');
    });
  }

  getSupItemDataContent(responseData:Object,contentName:any){
    return responseData[contentName];
  }

/*
getPage(page: number){
	this.allJobInfoService.getAllJobs().subscribe(data =>{
  		this.applicationList=data;
  		//console.log(data);
      });  
}
*/
}
