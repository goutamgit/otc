export class DbaSchedulerJobRunDetail {
	logId:number;
	logDate:Date;
    jobName:String;
    jobSubname:String;
    status:String;
    runDuration:String;
}
