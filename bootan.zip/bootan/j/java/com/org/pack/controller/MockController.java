/**
 * 
 */
package com.org.pack.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.org.pack.service.CurrentSchedulePopulationService;

/**
 * @author Anupam Biswas
 * 2020-12-03 01:08:14.844
 */
@RestController
@RequestMapping(value="/mock")
public class MockController {

	@Autowired
	CurrentSchedulePopulationService currentSchedulePopulationService;
	
	@GetMapping("/pupulate-current-service")
	public void populateCurrentSchedule() {
		currentSchedulePopulationService.populateTodaySchedule();
	}
	
	@GetMapping("/check-current-schedule")
	public void checkCurrentSchedule() {
		currentSchedulePopulationService.checkCurrentSchedule();
	}
}
