/**
 * 
 */
package com.org.pack.dao.repository;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.org.pack.domain.entity.ReportQueryMaster;

/**
 * @author Anupam Biswas
 * 2020-12-03 00:40:07.801
 */
@Repository
public interface ReportQueryMasterRepository extends PagingAndSortingRepository<ReportQueryMaster,Long>{

}
