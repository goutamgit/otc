/**
 * 
 */
package com.org.pack.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.org.pack.domain.entity.ReportScheduleAudit;

/**
 * @author Anupam Biswas
 * 2020-12-03 00:38:16.898
 */
@Repository
public interface ReportScheduleAuditRepository extends JpaRepository<ReportScheduleAudit, Long>{
	ReportScheduleAudit findFirstByReportQueryIdOrderByReportScheduleAuditIdDesc(long report_schedule_audit_id);
}
