/**
 * 
 */
package com.org.pack.scheduler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.org.pack.service.CurrentSchedulePopulationService;

/**
 * @author Anupam Biswas
 * 2020-12-07 02:48:54.253
 */
@Component
public class AutoReportMailScheduler {
	
	@Autowired
	CurrentSchedulePopulationService currentSchedulePopulationService;
	
	@Scheduled(cron = "${current.schedule.check.frequency}")
	public void checkCurrentSchedule() {
		currentSchedulePopulationService.checkCurrentSchedule();
	}
	
	//@Scheduled(cron = "${refresh.all.schedule.tasks}")
	public void refreshAllSchedule() {
		currentSchedulePopulationService.populateTodaySchedule();
	}
}
