/**
 * 
 */
package com.org.pack.conf;

import java.sql.Connection;
import java.sql.DriverManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * @author Anupam Biswas
 * 2020-11-15 20:10:14.206
 */
@Component
public class DBConnection {
	
	private static final Logger LOG = LoggerFactory.getLogger(DBConnection.class);

	@Value("${prd.db.jdbc.driver}")
	private  String jdbcDriver;
	
	@Value("${prd.db.jdbc.url}")
	private  String jdbcUrl;
	
	@Value("${prd.db.jdbc.username}")
	private  String jdbcUserName;
	
	@Value("${prd.db.jdbc.passowrd}")
	private  String jdbcPassword;
	
	public Connection conn() {
		try {
			Class.forName(jdbcDriver);
			Connection con=DriverManager.getConnection(jdbcUrl,jdbcUserName,jdbcPassword);  
			return con;
		} catch (Exception e) {
			LOG.error("Exception in jdbc connection {}",e.getMessage());
		}  
		return null;
	}
}
