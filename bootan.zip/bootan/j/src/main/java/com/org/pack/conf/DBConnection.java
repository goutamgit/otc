/**
 * 
 */
package com.org.pack.conf;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 * @author Anupam Biswas
 * 2020-11-15 20:10:14.206
 */
public class DBConnection {

	public static Connection conn() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/automailconfigurer","root","root");  
			return con;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
		return null;
	}
}
