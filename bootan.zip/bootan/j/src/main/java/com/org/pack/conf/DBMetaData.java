/**
 * 
 */
package com.org.pack.conf;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author Anupam Biswas
 * 2020-11-15 20:18:09.541
 */
@Component
public class DBMetaData {
	
	@Autowired
	DBConnection dbConnection;
	
	public void getQueryMetaData(String query) throws SQLException {
		int columnCounter = 1;
		Map<String,String> queryMetedata = new LinkedHashMap<>();
		Statement stmt=dbConnection.conn().createStatement();  
		List<Object[]> dataList = new ArrayList<>();
		ResultSet rs=stmt.executeQuery(query);  
		int resultColumnCount = rs.getMetaData().getColumnCount();
		while(resultColumnCount >= columnCounter) {
			queryMetedata.put(rs.getMetaData().getColumnName(columnCounter), rs.getMetaData().getColumnTypeName(columnCounter));
			//queryMetaDataList.add(columCount, rs.getMetaData().getColumnTypeName(columCount));
			columnCounter++;
			
		}
		while(rs.next()) {
			
			Object exdata[]  = new Object[resultColumnCount];
			int i =0;
			for (Map.Entry<String,String> entry : queryMetedata.entrySet())  {
	            if("INT".equals(entry.getValue())) {
	            	//rs.getInt(entry.getKey());
	            	System.out.println(rs.getInt(entry.getKey()));
	            	exdata[i] = rs.getInt(entry.getKey());
	            }
	            if("VARCHAR".equals(entry.getValue())) {
	            	//rs.getInt(entry.getKey());
	            	System.out.println(rs.getString(entry.getKey()));
	            	exdata[i] = rs.getString(entry.getKey());
	            }
	            i++;
	    } 
			dataList.add(exdata);
		}
		//rs.getMetaData().
		System.out.println(rs.getMetaData().getColumnName(2)); // print column name
		System.out.println(queryMetedata);
		
		XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheet = workbook.createSheet("Java Books");
        int rowCount = 0;
		for(Object[] obj : dataList) {
			Row row = sheet.createRow(++rowCount);
			int columnCount = 0;
			for(int i = 0; i<resultColumnCount;i++) {
				Cell cell = row.createCell(columnCount);
				if (obj[i] instanceof String) {
                    cell.setCellValue((String) obj[i]);
                } else if (obj[i] instanceof Integer) {
                    cell.setCellValue((Integer) obj[i]);
                }
				columnCount++;
				//System.out.println(obj[i]);
			}
		}
		
		try (FileOutputStream outputStream = new FileOutputStream("JavaBooks.xlsx")) {
            workbook.write(outputStream);
        } catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
