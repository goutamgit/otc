/**
 * 
 */
package com.org.pack.conf;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;


/**
 * @author Anupam Biswas
 * 2020-12-14 01:57:32.782
 */
@Component
public class MailProperties {

	private static final Logger LOG = LoggerFactory.getLogger(MailProperties.class);
	
	@Autowired
	Properties properties;
	
	@Value("${mail.smtp.host}")
	private String smtpHost;
	
	@Value("${mail.smtp.port}")
	private String smptPort;
	
	@Value("${mail.smpt.auth}")
	private String auth;
	
	private Properties getMailProperties() {
		properties.put("mail.smtp.host", smtpHost);
		properties.put("mail.smtp.port", smptPort);
		properties.put("mail.smpt.auth", auth);
		properties.put("mail.debug", "false");
		
		return properties;
	}
	
	public Message getMimeMessage() {
		
		Session session = Session.getDefaultInstance(getMailProperties());
		Message message = new MimeMessage(session);
		try {
			message.setFrom(new InternetAddress("sender"));
		} catch (MessagingException e) {
			LOG.error("Exception creating message sender {}",e.getMessage());
		}
		return message;
	}
	
}
