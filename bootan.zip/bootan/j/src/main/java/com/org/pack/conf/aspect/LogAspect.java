/**
 * 
 */
package com.org.pack.conf.aspect;

import java.util.Arrays;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;


/**
 * @author Anupam Biswas
 * 2020-12-07 01:31:24.524
 */
@Aspect
@Component
public class LogAspect {
	private static final Logger LOGGER = LogManager.getLogger(LogAspect.class);
	
	@Around("execution(* com.org.pack.controller.*.*(..)) || execution(* com.org.pack.service.*.*(..)) || execution(* com.org.pack.scheduler.*.*(..))")
    public Object profileAllMethods(ProceedingJoinPoint proceedingJoinPoint) throws Throwable 
    {
        MethodSignature methodSignature = (MethodSignature) proceedingJoinPoint.getSignature();
          
        //Get intercepted method details
        String className = methodSignature.getDeclaringType().getSimpleName();
        String methodName = methodSignature.getName();
       
        Object result = proceedingJoinPoint.proceed();
        
        Object[] arguments = proceedingJoinPoint.getArgs();
        List<Object> argumentsList = Arrays.asList(arguments);
  
        LOGGER.info("Executing.. " + className + "." + methodName + "Args : "+argumentsList);
  
        return result;
    }
}
