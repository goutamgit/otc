/**
 * 
 */
package com.org.pack.controller;


import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.org.pack.dao.repository.ReportQueryMasterRepository;
import com.org.pack.domain.entity.ReportQueryMaster;
import com.org.pack.service.CurrentSchedulePopulationService;
import com.org.pack.service.FileGeneratorService;
import com.org.pack.service.MailService;
import com.org.pack.service.ReportQueryMasterService;

/**
 * @author Anupam Biswas
 * 2020-12-10 01:06:05.724
 */
@RestController
@RequestMapping(value="/api")
@CrossOrigin
public class ReportGenerationMailController {
	
	@Autowired
	ReportQueryMasterRepository reportQueryMasterRepository;
	
	@Autowired
	ReportQueryMasterService reportQueryMasterService;
	
	@Autowired
	FileGeneratorService fileGeneratorService;
	
	@Autowired
	CurrentSchedulePopulationService currentSchedulePopulationService;
	
	@Autowired
	MailService mailService;

	@PostMapping("/save-new-report-configuration")
	public ResponseEntity<Object> createItem(@RequestBody ReportQueryMaster reportQueryMaster,UriComponentsBuilder builder) {
		ReportQueryMaster savedItem = reportQueryMasterRepository.save(reportQueryMaster);

		/*
		 * URI location =
		 * ServletUriComponentsBuilder.fromCurrentRequest().path("/item/{id}")
		 * .buildAndExpand(savedStudent.getId()).toUri();
		 * 
		 * return ResponseEntity.created(location).build();
		 */
		//System.err.println(savedItem.getReleaseId());
		HttpHeaders headers = new HttpHeaders();
        headers.setLocation(builder.path("item/{id}").buildAndExpand(savedItem.getReportQueryId()).toUri());
        return new ResponseEntity<Object>(headers,HttpStatus.CREATED);

	}
	
	@PutMapping("/update-report-configuration/{reportQueryId}")
	public ResponseEntity<Object> updateItem(@RequestBody ReportQueryMaster item, @PathVariable long reportQueryId) {
		
		ReportQueryMaster itemOptional = reportQueryMasterService.findReportQueryMasterById(reportQueryId).get();

		if (itemOptional==null)
			return ResponseEntity.notFound().build();

		item.setReportQueryId(reportQueryId);
		
		reportQueryMasterRepository.save(item);

		return ResponseEntity.noContent().build();
	}
	
	@GetMapping("/all-report-query-mail-list/{pageNumber}")
	public Page<ReportQueryMaster> retrieveAllItems(@PathVariable int pageNumber) {
		return reportQueryMasterService.findAllReportsList(pageNumber);
	}
	
	@GetMapping("/report-query-mail/{reportQueryId}")
	public ReportQueryMaster retrieveReportQueryMaster(@PathVariable int reportQueryId) {
		return reportQueryMasterService.findReportQueryMasterById(reportQueryId).get();
	}
	
	@DeleteMapping("/report-query-mail/{reportQueryId}")
	public void RemoveReportQueryMasterById(@PathVariable long reportQueryId) {
		reportQueryMasterService.RemoveReportQueryMasterById(reportQueryId);
	}
	
	@GetMapping("/report-query-mail-test/{reportQueryId}")
	public void retrieveReportQueryMasterTest(@PathVariable long reportQueryId) {
		ReportQueryMaster reportQueryMaster = reportQueryMasterService.findReportQueryMasterById(reportQueryId).get();
		String generatedFileName = fileGeneratorService.generateReportFile(reportQueryMaster);
		String patternString = ".*.xlsx.*";
		Pattern pattern = Pattern.compile(patternString);
		Matcher matcher = pattern.matcher(generatedFileName);
		if(matcher.matches()) {
			//mailService.sendReportMail(reportQueryMaster,generatedFileName);
		}
	}
	
	@GetMapping("/reload-query-mail-schedule")
	public void reloadCurrentQuerySchedule() {
		currentSchedulePopulationService.populateTodaySchedule();
	}
}
