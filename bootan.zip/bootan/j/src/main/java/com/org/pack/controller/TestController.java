/**
 * 
 */
package com.org.pack.controller;

import java.sql.SQLException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.org.pack.conf.DBMetaData;
import com.org.pack.dao.repository.ReportQueryMasterRepository;
import com.org.pack.domain.entity.ReportQueryMaster;
import com.org.pack.service.FileGeneratorService;

/**
 * @author Anupam Biswas
 * 2020-11-15 20:16:07.363
 */
@RestController
@RequestMapping(value="/api")
public class TestController {

	@Autowired 
	DBMetaData dbMetaData;
	
	@Autowired
	FileGeneratorService fileGeneratorService;
	
	@Autowired
	ReportQueryMasterRepository reportQueryMasterRepository;
	
	@GetMapping("/dbtest")
	public void dbTest() throws SQLException {
		dbMetaData.getQueryMetaData("select id,username,email from user1");
	}
	
	@GetMapping("/fileservice/{querymasterid}")
	public void dbTestService(@PathVariable Long querymasterid) throws SQLException {
		//dbMetaData.getQueryMetaData("select id,username,email from user1");
		Optional<ReportQueryMaster> reportQueryMaster = reportQueryMasterRepository.findById(querymasterid);
		
		fileGeneratorService.generateReportFile(reportQueryMaster.get());
	}
}
