/**
 * 
 */
package com.org.pack.dao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.org.pack.domain.entity.ReportQueryMaster;
import com.org.pack.domain.entity.ReportSchedule;

/**
 * @author Anupam Biswas
 * 2020-12-03 00:36:06.601
 */
@Repository
public interface ReportScheduleRepository extends JpaRepository<ReportSchedule, Long>{
	List<ReportSchedule> findAllByReportDayAndActiveInactive(String reportDaty,String activeInactive);
	List<ReportSchedule> findAllByReportQueryMaster(ReportQueryMaster reportQueryMaster);
}
