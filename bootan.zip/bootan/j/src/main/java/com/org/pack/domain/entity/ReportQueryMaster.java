/**
 * 
 */
package com.org.pack.domain.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @author Anupam Biswas
 * 2020-12-02 02:20:13.248
 */
@Entity
@Table(name = "report_query_master")
@Getter
@Setter
@ToString
public class ReportQueryMaster implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 7881134770673771927L;

	@Id
	@Column(name = "report_query_id")
	private long reportQueryId;
	
	@Column(name = "report_query")
	private String reportQuery;
	
	@Column(name = "mail_to")
	private String mailTo;
	
	@Column(name = "mail_cc")
	private String mailCc;
	
	@Column(name = "mail_subject")
	private String mailSubject;
	
	@Column(name = "mail_body")
	private String mailBody;
	
	@Column(name = "report_filename")
	private String reportFilename;
	
	@Column(name = "report_sheet_name")
	private String reportSheetName;
	
	@Column(name = "report_name")
	private String reportName;
	
	@Column(name = "report_description")
	private String reportDescription;
	
	@Column(name = "active_inactive")
	private String activeInactive;
}
