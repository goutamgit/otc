/**
 * 
 */
package com.org.pack.domain.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @author Anupam Biswas
 * 2020-12-02 02:18:30.240
 */
@Entity
@Table(name = "report_schedule")
@Getter
@Setter
@ToString
public class ReportSchedule implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 8696392665643799129L;

	@Id
	@Column(name = "report_schedule_id")
	private long reportScheduleId;
	
	/*
	 * @Column(name = "report_query_id") private int reportQueryId;
	 */
	
	@Column(name = "report_day")
	private String reportDay;
	
	@Column(name = "report_time")
	private String reportTime;
	
	@Column(name = "generate_report")
	private String generateReport;
	
	@Column(name = "send_mail")
	private String sendMail;
	
	@Column(name = "active_inactive")
	private String activeInactive;
	
	@Column(name = "created_date")
	@Temporal(TemporalType.TIMESTAMP)
	private java.util.Date createdDate;
	
	@ManyToOne
    @JoinColumn(name="report_query_id", nullable=false)
    private ReportQueryMaster reportQueryMaster;
	
}
