/**
 * 
 */
package com.org.pack.domain.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @author Anupam Biswas
 * 2020-12-02 02:23:57.134
 */
@Entity
@Table(name = "report_schedule_audit")
@Getter
@Setter
@ToString
public class ReportScheduleAudit implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 7372803002102259736L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "report_schedule_audit_id")
	private long reportScheduleAuditId;
	
	@Column(name = "report_query_id")
	private long reportQueryId;
	
	@Column(name = "report_schedule_id")
	private long reportScheduleId;
	
	@Column(name = "report_name")
	private String reportName;
	
	@Column(name = "generated_filename")
	private String generatedFilename;
	
	@Column(name = "report_generation_status")
	private String reportGenerationStatus;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "report_generation_time")
	private Date reportGenerationTime;
	
	@Column(name = "report_mail_send_status")
	private String reportMailSendStatus;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "report_mail_send_time")
	private Date reportMailSendTime;

}
