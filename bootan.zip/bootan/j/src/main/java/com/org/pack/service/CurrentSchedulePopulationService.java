/**
 * 
 */
package com.org.pack.service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.annotation.PostConstruct;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.org.pack.dao.repository.ReportScheduleAuditRepository;
import com.org.pack.dao.repository.ReportScheduleRepository;
import com.org.pack.domain.entity.ReportSchedule;
import com.org.pack.domain.entity.ReportScheduleAudit;
import com.org.pack.util.DateTimeUtil;

/**
 * @author Anupam Biswas
 * 2020-12-03 00:49:21.760
 */
@Service
public class CurrentSchedulePopulationService {
	
	@Autowired 
	ReportScheduleAuditRepository reportCurrentScheduleRepository;
	
	@Autowired
	ReportScheduleRepository reportScheduleRepository;
	
	@Autowired
	FileGeneratorService fileGeneratorService;
	
	@Autowired
	MailService mailService;
	
	/*
	 * @Autowired ReportScheduleAudit reportScheduleAudit;
	 */
	
	@Autowired
	ReportScheduleAuditRepository reportScheduleAuditRepository;
	
	public List<ReportSchedule> todayReportScheduleList;

	private static final Logger LOG = LoggerFactory.getLogger(CurrentSchedulePopulationService.class);
	
	@PostConstruct
	public void populateTodayListInit() {
		this.populateTodaySchedule();
	}
	
	public void populateTodaySchedule() {
		//System.out.println(DateTimeUtil.getCurrentDay());
		
		todayReportScheduleList = reportScheduleRepository.findAllByReportDayAndActiveInactive(DateTimeUtil.getCurrentDay().toUpperCase(), "A");
		/*
		 * for(ReportSchedule obj : todayReportScheduleList) {
		 * System.out.println(obj.toString());
		 * System.out.println(obj.getReportQueryMaster().toString()); }
		 */
	}
	
	public void checkCurrentSchedule() {
		List<ReportSchedule> todayReportScheduleListLocal = this.todayReportScheduleList;
		todayReportScheduleListLocal.stream()
		//.filter(t->t.getReportTime().equals(DateTimeUtil.getCurrentTime()))
		.filter(t->t.getActiveInactive().equals("A"))
		//.parallel()
		.forEach(n->generateReport(n));
	}
	
	@Transactional
	public void generateReport(ReportSchedule reportSchedule) {
		String generatedFileName = null;
		String mailSendStatus = null;
		
		ReportScheduleAudit reportScheduleAudit = new ReportScheduleAudit();
		if(reportSchedule.getGenerateReport().equals("Y")) {
			generatedFileName = fileGeneratorService.generateReportFile(reportSchedule.getReportQueryMaster());
			String patternString = ".*.xlsx.*";
			Pattern pattern = Pattern.compile(patternString);
			Matcher matcher = pattern.matcher(generatedFileName);
			if(matcher.matches()) {
				reportScheduleAudit.setGeneratedFilename(generatedFileName);
				reportScheduleAudit.setReportGenerationStatus("generated");
			}else {
				reportScheduleAudit.setReportGenerationStatus(generatedFileName);
			}
			
			reportScheduleAudit.setReportGenerationTime(new Date());
			reportScheduleAudit.setReportQueryId(reportSchedule.getReportQueryMaster().getReportQueryId());
			reportScheduleAudit.setReportScheduleId(reportSchedule.getReportScheduleId());
			
			
			if(reportSchedule.getSendMail().equals("Y")) {
				if(reportScheduleAudit.getReportGenerationStatus().equals("generated")) {
					mailSendStatus = mailService.sendReportMail(reportSchedule.getReportQueryMaster(),generatedFileName);
					LOG.info("Mail Sending status {}",mailSendStatus);
					reportScheduleAudit.setReportMailSendStatus(mailSendStatus);
					reportScheduleAudit.setReportMailSendTime(new Date());
				}				
			}
			
			
			reportScheduleAuditRepository.save(reportScheduleAudit);
			fileMover(reportScheduleAudit);
		}
	}
	
	private void fileMover(ReportScheduleAudit reportScheduleAudit) {
		File currDir = new File("");
        String sourceFile = currDir.getAbsolutePath()+"/generated-file/"+reportScheduleAudit.getGeneratedFilename();
		String targetLocation = currDir.getAbsolutePath()+"/processed-file/"+reportScheduleAudit.getGeneratedFilename();        
		try {
			File sourceFileCheck = new File(sourceFile);
			if(sourceFileCheck.exists()) {
				Files.move(Paths.get(sourceFile), Paths.get(targetLocation));
				LOG.info("file moved to processed");
			}
		} catch (IOException e) {
			LOG.error("Exception in file movement to processed {}",e.getMessage());
		}
	}
}
