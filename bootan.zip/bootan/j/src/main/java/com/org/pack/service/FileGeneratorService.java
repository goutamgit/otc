/**
 * 
 */
package com.org.pack.service;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.org.pack.conf.DBConnection;
import com.org.pack.dao.repository.ReportScheduleAuditRepository;
import com.org.pack.domain.entity.ReportQueryMaster;
import com.org.pack.domain.entity.ReportScheduleAudit;

/**
 * @author Anupam Biswas
 * 2020-11-30 00:51:07.182
 */
@Service
public class FileGeneratorService {
	
	@Autowired
	ReportScheduleAuditRepository reportScheduleAuditRepository;
	
	
	private static final Logger LOG = LoggerFactory.getLogger(FileGeneratorService.class);
	private String fileLocation = null;
	List<Object[]> dataList = null;
	ReportScheduleAudit reportScheduleAudit = new ReportScheduleAudit();
	public String generateReportFile(ReportQueryMaster reportQueryMaster) {
		
		ResultSet rs = getResultSetByQuery(reportQueryMaster.getReportQuery());
		//List<Object[]> dataList = this.generateReportDBData(reportQueryMaster.getReportQuery());
		Map<String,String> headerMetaData = getQueryMetadataFromResutset(rs);
		if(!headerMetaData.isEmpty() || headerMetaData!=null) {
			dataList = this.generateReportDBData(rs,headerMetaData);
		}
		
		if(dataList.isEmpty() || dataList==null) {
			LOG.info("No result fetch from query");
			return "No Result Fetched! Please check query";
		}else {
			LOG.info("Fetched {} Records from DB ",dataList.size());
			XSSFWorkbook workbook = new XSSFWorkbook();
			XSSFSheet sheet = workbook.createSheet(reportQueryMaster.getReportSheetName());			
			
			Row headerRow = sheet.createRow(0);
			int headerColumnCount = 0;
			for (Map.Entry<String, String> entry : headerMetaData.entrySet()) {
				Cell headerCell = headerRow.createCell(headerColumnCount); 
				headerCell.setCellValue(entry.getKey().toUpperCase());
			      headerColumnCount++;
			    }
			
			
			
	        int rowCount = 0;
			for(Object[] obj : dataList) {
				Row row = sheet.createRow(++rowCount);
				int columnCount = 0;
				for(int i = 0; i<obj.length;i++) {
					Cell cell = row.createCell(columnCount);
					if (obj[i] instanceof String) {
	                    cell.setCellValue((String) obj[i]);
	                } else if (obj[i] instanceof Integer) {
	                    cell.setCellValue((Integer) obj[i]);
	                }
					columnCount++;
					//System.out.println(obj[i]);
				}
			}
			File currDir = new File(".");
	        String path = currDir.getAbsolutePath()+"/generated-file/";
	        //fileLocation = path.substring(0, path.length() - 1) + reportQueryMaster.getReportFilename();
	        String generatedFileName = reportQueryMaster.getReportFilename()+generateFileVersion(reportQueryMaster.getReportQueryId());
	        fileLocation = path + generatedFileName;
	        
			try (FileOutputStream outputStream = new FileOutputStream(fileLocation)) {
	            workbook.write(outputStream);
	            workbook.close();
	            return generatedFileName;
	        } catch (FileNotFoundException e) {
	        	LOG.error("Exception - FileNotFound {}",e.getMessage());
	        	return "FileNotFoundException";
			} catch (IOException e) {
				LOG.error("Exception - IO {}",e.getMessage());
				return "IOException";
			}
		}
	}
	
	private List<Object[]> generateReportDBData(ResultSet rs,Map<String,String> queryMetedata){
		
		List<Object[]> dataList = new ArrayList<>();
		
		try {
			
			int resultColumnCount = rs.getMetaData().getColumnCount();
			LOG.info("Fetched {} result form query ",resultColumnCount);

			
			while(rs.next()) {
				
				Object exdata[]  = new Object[resultColumnCount];
				int i =0;
				for (Map.Entry<String,String> entry : queryMetedata.entrySet())  {
		            if("INT".equals(entry.getValue())) {
		            	//rs.getInt(entry.getKey());
		            	//System.out.println(rs.getInt(entry.getKey()));
		            	exdata[i] = rs.getInt(entry.getKey());
		            }
		            if("VARCHAR".equals(entry.getValue())) {
		            	//rs.getInt(entry.getKey());
		            	//System.out.println(rs.getString(entry.getKey()));
		            	exdata[i] = rs.getString(entry.getKey());
		            }
		            i++;
				} 
				dataList.add(exdata);
			}
			
		} catch (SQLException e) {
			LOG.error("Exception in getting metadara {}",e.getMessage());
		}  
		
		
		return dataList;
	}
	private ResultSet getResultSetByQuery(String query) {
		Statement stmt;
		ResultSet rs = null;
		try {
			stmt = DBConnection.conn().createStatement();
			rs=stmt.executeQuery(query); 
			LOG.info("Creating ResultSet from query {} ",query);
		} catch (SQLException e) {
			LOG.error("Exception in query execution {}",e.getMessage());
		}
		return rs;
	}
	
	private Map<String,String> getQueryMetadataFromResutset(ResultSet rs){
		int columnCounter = 1;
		//Map<String,String> queryMetedata = Collections.synchronizedMap(new LinkedHashMap<>());
		Map<String,String> queryMetedata = new LinkedHashMap<>();
		try {
			
			int resultColumnCount = rs.getMetaData().getColumnCount();
			LOG.info("Fetched total {} result form query ",resultColumnCount);
			while(resultColumnCount >= columnCounter) {
				queryMetedata.put(rs.getMetaData().getColumnName(columnCounter), rs.getMetaData().getColumnTypeName(columnCounter));
				columnCounter++;
			}
		} catch (SQLException e) {
			LOG.error("Exception in query metadata execution {}",e.getMessage());
		}
		return queryMetedata;
	}
	
	private String generateFileVersion(long queryId) {
		String version = null;
		ReportScheduleAudit reportScheduleAudit = reportScheduleAuditRepository.findFirstByReportQueryIdOrderByReportScheduleAuditIdDesc(queryId);
		if(reportScheduleAudit!=null) {
			if(reportScheduleAudit.getGeneratedFilename() == null || reportScheduleAudit.getGeneratedFilename().isEmpty()) {
				version = "_v1.xlsx";
			}else {
				String fileNameParts[] = reportScheduleAudit.getGeneratedFilename().split("_");
				int fileNamePartSize = fileNameParts.length;
				String lastPartArr[] = fileNameParts[fileNamePartSize-1].split("\\.");
				int currentCounter = Integer.parseInt(lastPartArr[0].substring(1))+1 ; 
				version = "_v"+currentCounter+".xlsx";
			}
		}else {
			version = "_v1.xlsx";
		}
		
		return version;
	}
	
	/*
	public List<Object[]> generateReportDBData(String query) {
		
		int columnCounter = 1;
		List<Object[]> dataList = new ArrayList<>();
		//Map<String,String> queryMetedata = new LinkedHashMap<>();
		Map<String,String> queryMetedata = Collections.synchronizedMap(new LinkedHashMap<>());
		
		Statement stmt;
		try {
			stmt = DBConnection.conn().createStatement();
			ResultSet rs=stmt.executeQuery(query); 
			int resultColumnCount = rs.getMetaData().getColumnCount();
			LOG.info("Fetched {} result for query {}",resultColumnCount,query);
			while(resultColumnCount >= columnCounter) {
				queryMetedata.put(rs.getMetaData().getColumnName(columnCounter), rs.getMetaData().getColumnTypeName(columnCounter));
				columnCounter++;
			}
			
			while(rs.next()) {
				
				Object exdata[]  = new Object[resultColumnCount];
				int i =0;
				for (Map.Entry<String,String> entry : queryMetedata.entrySet())  {
		            if("INT".equals(entry.getValue())) {
		            	//rs.getInt(entry.getKey());
		            	//System.out.println(rs.getInt(entry.getKey()));
		            	exdata[i] = rs.getInt(entry.getKey());
		            }
		            if("VARCHAR".equals(entry.getValue())) {
		            	//rs.getInt(entry.getKey());
		            	//System.out.println(rs.getString(entry.getKey()));
		            	exdata[i] = rs.getString(entry.getKey());
		            }
		            i++;
				} 
				dataList.add(exdata);
			}
			
		} catch (SQLException e) {
			LOG.error("Exception in getting metadara {}",e.getMessage());
		}  
		
		
		return dataList;
	}
	*/

	
}
