/**
 * 
 */
package com.org.pack.service;

import java.io.File;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMultipart;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.org.pack.conf.MailProperties;
import com.org.pack.domain.entity.ReportQueryMaster;

/**
 * @author Anupam Biswas
 * 2020-12-05 19:17:42.714
 */
@Service
public class MailService {

	private static final Logger LOG = LoggerFactory.getLogger(MailService.class);
	
	@Autowired
	MailProperties mailProperties;
	
	public String sendReportMail(ReportQueryMaster reportQueryMaster,String generatedFileName){
		String mailTo = reportQueryMaster.getMailTo();
		String mailCc = reportQueryMaster.getMailCc();
		String mailSubject = reportQueryMaster.getMailSubject();
		String mailBody = reportQueryMaster.getMailBody();
		
		Message message = mailProperties.getMimeMessage();
		try {
			InternetAddress[] mailToList = InternetAddress.parse(mailTo);
			InternetAddress[] mailCcList = InternetAddress.parse(mailCc);
			
			message.setRecipients(Message.RecipientType.TO, mailToList);
			message.setRecipients(Message.RecipientType.CC, mailCcList);
			
			message.setSubject(mailSubject);
			
			Multipart multipart = new MimeMultipart();
			BodyPart messageBodyPart = new MimeBodyPart();
			BodyPart attachmentBodyPart = new MimeBodyPart();
			
			messageBodyPart.setContent(mailBody,"text/html; charset=utf-8");
			multipart.addBodyPart(messageBodyPart);
			
			File currDir = new File("");
			String sourceFile = currDir.getAbsolutePath()+"/generated-file/"+generatedFileName;
			File fileName = new File(sourceFile);
			
			DataSource source = new FileDataSource(fileName);
			attachmentBodyPart.setDataHandler(new DataHandler(source));
			attachmentBodyPart.setFileName(generatedFileName);
			
			message.setContent(multipart);
			Transport.send(message);
			
		} catch (MessagingException e) {
			LOG.error("Exception in mail send {}",e.getMessage());
			return "failedMessage";
		}
		
		return "mailsend";
		
	}
}
