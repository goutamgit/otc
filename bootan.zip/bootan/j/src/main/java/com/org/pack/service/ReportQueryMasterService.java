/**
 * 
 */
package com.org.pack.service;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.org.pack.dao.repository.ReportQueryMasterRepository;
import com.org.pack.domain.entity.ReportQueryMaster;

/**
 * @author Anupam Biswas
 * 2020-12-10 01:17:30.544
 */
@Service
public class ReportQueryMasterService {

	@Autowired
	ReportQueryMasterRepository reportQueryMasterRepository;
	
	private static final Logger LOG = LoggerFactory.getLogger(ReportQueryMasterService.class);
	
	public Page<ReportQueryMaster> findAllReportsList(int pageNumber) {
		Pageable pageable = PageRequest.of(pageNumber-1, 50, Sort.by("reportQueryId").descending());
		return reportQueryMasterRepository.findAll(pageable);
	}
	
	public Optional<ReportQueryMaster> findReportQueryMasterById(long reportQueryId) {
		return reportQueryMasterRepository.findById(reportQueryId);
	}
	
	public void RemoveReportQueryMasterById(long reportQueryId) {
		reportQueryMasterRepository.deleteById(reportQueryId);
	}
}
