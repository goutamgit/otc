/**
 * 
 */
package com.org.pack.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.org.pack.dao.repository.ReportQueryMasterRepository;
import com.org.pack.dao.repository.ReportScheduleRepository;
import com.org.pack.domain.entity.ReportQueryMaster;
import com.org.pack.domain.entity.ReportSchedule;

/**
 * @author Anupam Biswas
 * 2020-12-20 19:21:52.750
 */
@Service
public class ReportScheduleService {
	
	@Autowired
	ReportScheduleRepository reportScheduleRepository;
	
	@Autowired
	ReportQueryMasterRepository reportQueryMasterRepository;

	public List<ReportSchedule> getReportScheduleIdByReportQueryID(Long reportQueryId){
		ReportQueryMaster reportQueryMaster = reportQueryMasterRepository.findById(reportQueryId).get();
		return reportScheduleRepository.findAllByReportQueryMaster(reportQueryMaster);
	}
}
