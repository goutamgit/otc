/**
 * 
 */
package com.org.pack.util;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author Anupam Biswas
 * 2020-12-03 01:45:56.839
 */
public class DateTimeUtil {
	public static String getCurrentDay(){
		Date now = new Date();
		SimpleDateFormat simpleDateformat = new SimpleDateFormat("E"); // the day of the week abbreviated
		//SimpleDateFormat simpleDateformat1 = new SimpleDateFormat("EEEE"); // the day of the week spelled out completely
        //System.out.println(simpleDateformat1.format(now));
        return simpleDateformat.format(now);
	}
	
	public static String getCurrentTime() {
		Date now = new Date();
		SimpleDateFormat simpleDateformat = new SimpleDateFormat("hh:mm a"); 
		return simpleDateformat.format(now);
	}
	
	public static String getDateStr(Date date) {
		SimpleDateFormat simpleDateformat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss"); 
		return simpleDateformat.format(date);
	}
	
}
