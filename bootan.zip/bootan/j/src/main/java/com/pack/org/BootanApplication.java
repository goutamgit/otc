package com.pack.org;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootanApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootanApplication.class, args);
	}
	
}
