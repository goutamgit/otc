/**
 * 
 */
package com.pack.org.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pack.org.domain.entity.DbaSchedulerJobRunDetail;
import com.pack.org.service.DbaSchedulerJobRunDetailService;


/**
 * @author Anupam Biswas
 * 2020-10-10 18:57:15.369
 */
@RestController
@RequestMapping(value="/jobdetail")
public class DbaSchedulerJobRunDetailController {
	
	@Autowired
	DbaSchedulerJobRunDetailService dbaSchedulerJobRunDetailService;
	
	@GetMapping("/job-run-detail/{page}/{srcsupitemstr}")
	public Page<DbaSchedulerJobRunDetail> retrieveAdvanceSearchSupportItem(@PathVariable int page,@PathVariable String srcsupitemstr) {
		return dbaSchedulerJobRunDetailService.getAdvSrcSupportItem(srcsupitemstr,page);
	}
}
