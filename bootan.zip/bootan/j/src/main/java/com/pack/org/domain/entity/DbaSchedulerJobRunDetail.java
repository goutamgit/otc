/**
 * 
 */
package com.pack.org.domain.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @author Anupam Biswas
 * 2020-10-10 18:31:34.781
 */
@Entity
@Table(name = "dba_scheduler_job_run_detail")
@Getter
@Setter
@ToString
public class DbaSchedulerJobRunDetail implements Serializable{/**
	 * 
	 */
	private static final long serialVersionUID = -4716245391938826881L;
	
	@Id
	@Column(name = "log_id")
	private long logId;
	
	@Column(name = "log_date")
	@Temporal(TemporalType.TIMESTAMP)
	private java.util.Date logDate;
	
	@Column(name = "job_name")
	private String jobName;
	
	@Column(name = "job_subname")
	private String jobSubname;
	
	@Column(name = "status")
	private String status;
	
	@Column(name = "run_duration")
	private String runDuration;

}
