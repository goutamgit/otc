/**
 * 
 */
package com.pack.org.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.pack.org.domain.entity.DbaSchedulerJobRunDetail;
import com.pack.org.dto.DbaSchedulerJobRunDetailDTO;
import com.pack.org.service.DbaSchedulerJobRunDetailService;
import com.pack.org.service.helper.DbaSchedulerJobRunDetailServiceHelper;

/**
 * @author Anupam Biswas
 * 2020-10-10 19:05:20.858
 */
@Component
public class DbaSchedulerJobRunDetailServiceImpl implements DbaSchedulerJobRunDetailService{

	private static final Logger LOGGER = LoggerFactory.getLogger(DbaSchedulerJobRunDetailServiceImpl.class);
	
	@Autowired
	Gson gson;
	
	@Autowired
	DbaSchedulerJobRunDetailServiceHelper dbaSchedulerJobRunDetailServiceHelper;
	
	@Override
	public Page<DbaSchedulerJobRunDetail> getAdvSrcSupportItem(String advanceSearchSupportItem, int pageNumber) {
		LOGGER.info("JOB search input {}",advanceSearchSupportItem);
		DbaSchedulerJobRunDetailDTO advSrcAttributes = gson.fromJson(advanceSearchSupportItem, DbaSchedulerJobRunDetailDTO.class);
		LOGGER.info("JOB search input JSON {}",advSrcAttributes);
		Pageable pageable = PageRequest.of(pageNumber-1, 50);
		LOGGER.info("JOB search input page number {}",pageable);
		Page<DbaSchedulerJobRunDetail> srcitem = dbaSchedulerJobRunDetailServiceHelper.retrieveAdvSrcSupportItemPage(advSrcAttributes,pageable);
		return srcitem;
	}

}
