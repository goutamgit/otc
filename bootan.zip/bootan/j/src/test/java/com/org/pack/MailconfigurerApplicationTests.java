package com.org.pack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MailconfigurerApplicationTests {

	@Test
	void contextLoads() {
	}

}
