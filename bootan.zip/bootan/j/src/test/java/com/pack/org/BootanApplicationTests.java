package com.pack.org;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootanApplicationTests {

	@Test
	void contextLoads() {
	}

}
