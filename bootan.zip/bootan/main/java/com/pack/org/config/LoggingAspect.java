/**
 * 
 */
package com.pack.org.config;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;



/**
 * @author Anupam Biswas
 * 2020-10-16 00:49:45.209
 */
@Aspect
@Component
public class LoggingAspect {
	private static final Logger LOGGER = LogManager.getLogger(LoggingAspect.class);
	
	@Around("execution(* com.pack.org.controller.*.*(..)) || execution(* com.pack.org.service.*.*(..)) || execution(* com.pack.org.service.helper.*.*(..)) || execution(* com.pack.org.service.impl.*.*(..))")
    public Object profileAllMethods(ProceedingJoinPoint proceedingJoinPoint) throws Throwable 
    {
        MethodSignature methodSignature = (MethodSignature) proceedingJoinPoint.getSignature();
          
        //Get intercepted method details
        String className = methodSignature.getDeclaringType().getSimpleName();
        String methodName = methodSignature.getName();
       
        Object result = proceedingJoinPoint.proceed();
  
        LOGGER.info("Executing.. " + className + "." + methodName );
  
        return result;
    }
}
