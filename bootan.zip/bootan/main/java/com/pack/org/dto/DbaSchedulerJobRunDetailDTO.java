/**
 * 
 */
package com.pack.org.dto;

import java.util.Date;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @author Anupam Biswas
 * 2020-10-10 19:08:07.462
 */
@Component
@Getter
@Setter
@ToString
public class DbaSchedulerJobRunDetailDTO {
	private String logDate;
	private String jobName;
	private String jobSubname;
	private String status;
	private String runDuration;
}
