/**
 * 
 */
package com.pack.org.service;

import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import com.pack.org.domain.entity.DbaSchedulerJobRunDetail;


/**
 * @author Anupam Biswas
 * 2020-10-10 18:55:04.471
 */
@Service
public interface DbaSchedulerJobRunDetailService {

	public Page<DbaSchedulerJobRunDetail> getAdvSrcSupportItem(String advanceSearchSupportItem,int pageNumber);
}
