/**
 * 
 */
package com.pack.org.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.pack.org.domain.entity.DbaSchedulerJobRunDetail;
import com.pack.org.dto.DbaSchedulerJobRunDetailDTO;
import com.pack.org.service.DbaSchedulerJobRunDetailService;
import com.pack.org.service.helper.DbaSchedulerJobRunDetailServiceHelper;

/**
 * @author Anupam Biswas
 * 2020-10-10 19:05:20.858
 */
@Component
public class DbaSchedulerJobRunDetailServiceImpl implements DbaSchedulerJobRunDetailService{

	@Autowired
	Gson gson;
	
	@Autowired
	DbaSchedulerJobRunDetailServiceHelper dbaSchedulerJobRunDetailServiceHelper;
	
	@Override
	public Page<DbaSchedulerJobRunDetail> getAdvSrcSupportItem(String advanceSearchSupportItem, int pageNumber) {
		System.out.println(advanceSearchSupportItem);
		DbaSchedulerJobRunDetailDTO advSrcAttributes = gson.fromJson(advanceSearchSupportItem, DbaSchedulerJobRunDetailDTO.class);
		System.out.println(advSrcAttributes);
		Pageable pageable = PageRequest.of(pageNumber-1, 3);
		System.out.println("page number"+pageNumber);
		Page<DbaSchedulerJobRunDetail> srcitem = dbaSchedulerJobRunDetailServiceHelper.retrieveAdvSrcSupportItemPage(advSrcAttributes,pageable);
		return srcitem;
	}

}
