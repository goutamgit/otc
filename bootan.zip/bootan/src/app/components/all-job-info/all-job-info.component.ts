import { Component, OnInit } from '@angular/core';
import { FormControl,FormGroup,Validators} from '@angular/forms';
import { DatePipe } from '@angular/common';
import{ GlobalConstants } from '../../conf/global-constants';
import { AllJobInfoService } from '../../service/all-job-info.service';
import { DbaSchedulerJobRunDetailDTO } from '../../dto/dba-scheduler-job-run-detail-dto';

@Component({
  selector: 'app-all-job-info',
  templateUrl: './all-job-info.component.html',
  styleUrls: ['./all-job-info.component.css']
})
export class AllJobInfoComponent implements OnInit {

applicationList:any;
supitemadvsearchattribute : DbaSchedulerJobRunDetailDTO = new DbaSchedulerJobRunDetailDTO();

  constructor(private allJobInfoService: AllJobInfoService) { 

this.config = {
      currentPage: 1,
      itemsPerPage: 3,
      totalItems:3
    };
  }

config: any; 
items: any[];
allJobName : any ;
allJobStstus : any ;
jobSearchObj : DbaSchedulerJobRunDetailDTO = new  DbaSchedulerJobRunDetailDTO();



  ngOnInit(): void {
  this.getPage(1);
  }

  getPage(page: number){
    this.loadPageConfiguration();
    this.config.currentPage=page;
    this.supitemadvsearchattribute = new DbaSchedulerJobRunDetailDTO();
    this.supitemadvsearchattribute.logDate = null;
    this.supitemadvsearchattribute.jobName = '';
    this.supitemadvsearchattribute.jobSubname = '';
    this.supitemadvsearchattribute.status = '';
    this.supitemadvsearchattribute.runDuration = '';

    console.log(this.supitemadvsearchattribute);
    this.allJobInfoService.getAllJobDetail(this.supitemadvsearchattribute,page).subscribe(data =>{
        this.items = this.getSupItemDataContent(data,'content');
        console.log(data);
        this.config.totalItems = this.getSupItemDataContent(data,'totalElements');
    });
  }

  getSupItemDataContent(responseData:Object,contentName:any){
    return responseData[contentName];
  }

  loadPageConfiguration(){
    this.allJobName = GlobalConstants.allJobName;
    this.allJobStstus = GlobalConstants.allJobStstus;
  }

    jobSearchForm=new FormGroup({
    search_job_name:new FormControl(),
    search_job_status:new FormControl(),
    search_job_date:new FormControl(),
  });

      jobSearchFormSubmit(){
      this.jobSearchObj = new DbaSchedulerJobRunDetailDTO();
      this.jobSearchObj.logDate = this.getSRCLogDate.value;
      this.jobSearchObj.jobName = this.getSRCJobName.value;
      this.jobSearchObj.status = this.getSRCJobStstus.value;
      console.log(this.jobSearchObj);
      this.getPage(1);
  }

  get getSRCLogDate(){
    return this.jobSearchForm.get('search_job_date');
  }

  get getSRCJobName(){
    return this.jobSearchForm.get('search_job_name');
  }

  get getSRCJobStstus(){
    return this.jobSearchForm.get('search_job_status');
  }

}
