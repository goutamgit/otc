export class GlobalConstants {

public static apiURL: string = "http://localhost:8080/jobdetail";
public static allJobName = ["name-1","name-2","name-3"];

}
