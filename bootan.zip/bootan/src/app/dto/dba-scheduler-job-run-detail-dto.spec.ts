import { DbaSchedulerJobRunDetailDTO } from './dba-scheduler-job-run-detail-dto';

describe('DbaSchedulerJobRunDetailDTO', () => {
  it('should create an instance', () => {
    expect(new DbaSchedulerJobRunDetailDTO()).toBeTruthy();
  });
});
