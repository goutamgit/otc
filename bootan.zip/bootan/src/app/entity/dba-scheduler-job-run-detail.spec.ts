import { DbaSchedulerJobRunDetail } from './dba-scheduler-job-run-detail';

describe('DbaSchedulerJobRunDetail', () => {
  it('should create an instance', () => {
    expect(new DbaSchedulerJobRunDetail()).toBeTruthy();
  });
});
